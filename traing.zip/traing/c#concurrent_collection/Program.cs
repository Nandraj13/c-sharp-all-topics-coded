﻿using System.Collections.Concurrent;

internal class Program
    {
        static ConcurrentDictionary<int,string> newDict = new ConcurrentDictionary<int, string>();
        static void Main(string[] args)
        {
            
            Thread t1 = new Thread(thread1);
            Thread t2 = new Thread(thread2);
            t1.Start();
            t2.Start();
            t1.Join();
            t2.Join();
            foreach (int key in newDict.Keys)
            {
                
                    Console.WriteLine(key+" "+newDict[key]);
                
            }
            
        }
        public static void thread1()
        {
            for(int i=0;i<10;i++)
            {
                newDict.TryAdd(i, "added by thread1");
                Thread.Sleep(200);
            }
        }
        public static void thread2()
        {
            for (int i = 0; i < 10; i++)
            {
                newDict.TryAdd(i, "added by thread2");
                Thread.Sleep(200);
            }
        }
       
    }