class Overloading{
    public void m1(int x,int y){
        Console.WriteLine(x+y);
    }
    public void m1(double x, double y){
        Console.WriteLine(x+y);
    }
}