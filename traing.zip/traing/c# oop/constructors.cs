class Cons{
    string name,surename;
    public Cons(){
        name="chirag";
        surename="maru";
    }
    public void dispagain(){
        Console.WriteLine(name+" "+surename);
    }
}