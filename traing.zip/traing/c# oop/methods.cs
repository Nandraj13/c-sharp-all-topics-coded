class Methods{
    string name="nandraj";
    string surename="maru";
    public void disp(){
        Console.WriteLine(name+" "+surename);
    }
}