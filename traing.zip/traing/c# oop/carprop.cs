class Carprop{
   public string color="red";
    public string tyre="apollo";
}