class Accesss{
    public string name="david";
    private string sname="miller";
    protected string fname="mathew";
}