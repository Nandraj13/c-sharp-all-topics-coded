﻿/*class delegates{
    delegate void adder (int a,int b); 
    delegate void subtractor(int a, int b);
    public static void add(int a,int b)
    {
        Console.WriteLine(a+b);
    }
    public static void sub(int a,int b)
    {
        Console.WriteLine(a-b);
    }
    public static void mul(int a, int b)
    {
        Console.WriteLine(a*b);
    }
    static void Main(string[] args)
    {
        adder a1= new adder(add);
        a1+=sub;
        a1+=mul;
        a1(100,20);
    }
}*/

//example 2
class delegates{
    static int ans=0;
    delegate void adder(int a,int b);
    public static void add(int a,int b)
    {
        ans=a+b;
    }
    public static void display(int a,int c)
    {
       Console.WriteLine(ans);
    }
    static void Main(string[] args)
    {
        adder a1=new adder(add);
        a1+=display;
        a1(10,20);
    }
}