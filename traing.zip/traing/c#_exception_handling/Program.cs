﻿/*class Exception_handling{
    static void Main(string[] args)
    {
        int x=10;
        int y=0;
        int[] arr=new int[5]{1,2,3,4,5};
        try
        {
            try{
                //Console.WriteLine(arr[10]);
                Console.WriteLine(x/y);
            }
            catch(ArithmeticException e)
            {
                Console.WriteLine(e.Message);
            }
        }
        catch(Exception e){
            Console.WriteLine("exception catched: "+e.Message);
        }
        }
}*/

//example 2
/*class student{
    public string studentname;
}
class InvalidStudentNameException: Exception{
    public InvalidStudentNameException(string name):base(String.Format("invalid name {0}",name)){
        
    }

}
class verifier{
    static void Main(string[] args)
    {
        try{
        student s=new student();
        s.studentname="nasndraj";
        verify(s.studentname);}
        catch(InvalidStudentNameException e)
        {
            Console.WriteLine(e);
        }
    }
    public static void verify(string s)
    {
        if(s!="nandraj")
          {  throw new InvalidStudentNameException(s);}
        else{
            Console.WriteLine("valid name");
        }

    }
}*/

// example custom exception

class customexception{
    static void Main(string[] args)
    {
        try{
             int age=Convert.ToInt32(Console.ReadLine());
             cantheyvote(age);
        }
        catch(YouCanNotVoteException e)
        {
            Console.WriteLine(e);
        }
    }
    public static void cantheyvote(int age)
    {
        if(age<18)
        {
            throw new YouCanNotVoteException(age);
        }
        else{
            Console.WriteLine("you are eligible to vote.");
        }
    }
}
class YouCanNotVoteException:Exception{
    public YouCanNotVoteException(int age):base(String.Format("your age is less than 18")){}
}