﻿class Tasks{
    static async void Main(string[] args)
    {
        var x = await task1();
        Console.WriteLine(x);
        task2();
    }
    public static Task<int> task1()
    {
        var t=new Task<int>(()=>{
             Thread.Sleep(2000);
            int result=0;
            for(int i=0;i<1000;i++)
            {
               result+=i;
            }
            return result;
        });
        t.Start();
        t.Wait();
        return t;
    }
    public static void task2()
    {
        var t=new Task(()=>{
            for(int i=0;i<5;i++)
            {
               
                Console.WriteLine("hello again");
            }
        });
        t.Start();
        t.Wait();
    }
}

