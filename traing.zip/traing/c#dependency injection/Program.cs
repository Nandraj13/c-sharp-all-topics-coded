﻿public interface Iaccounts{
    public void printdetails();
}
/*public class savingsaccount:Iaccounts{
    public void printdetails()
    {
        Console.WriteLine("this is a saving account");
    }
}
public class currentaccount:Iaccounts{
    public void printdetails()
    {
        Console.WriteLine("this is a current account");
    }
}

public class account {
    private Iaccounts ic;
    public account(Iaccounts a){
        ic=a;
    }
    public void runner(){
        ic.printdetails();
    }
}
    
public class program
{
    static void Main(string[] args)
    {
        savingsaccount sa=new savingsaccount();
        currentaccount ca=new currentaccount();
        account acc=new account(sa);
        acc.runner();
    }
}
*/
//dependency injection using properties
/*public class Savingsaccount: Iaccounts{
   public void printdetails(){
    Console.WriteLine("this is a saving account");
   }
}
public class Currentaccount: Iaccounts{
    public void printdetails(){
        Console.WriteLine("this is a current account");
    }
}

public class account{
     public Iaccounts details{get;set;}
    public void runner()
    {
        details.printdetails();
    }
}

public class program{
    static void Main(string[] args)
    {
         Savingsaccount sa=new Savingsaccount();
         Currentaccount ca=new Currentaccount();
         account acc=new account();
         acc.details=ca;
         acc.runner();
    }
}*/

//dependency injection using method
public class savingsaccount:Iaccounts{
    public void printdetails()
    {
        Console.WriteLine("this is a savings account");
    }
}
public class currentaccount:Iaccounts{
    public void printdetails()
    {
        Console.WriteLine("this is a current account");
    }
}
public class account{
    private Iaccounts icc;
    public void signer(Iaccounts icc)
    {
        this.icc=icc;
        this.icc.printdetails();
    }
}
public class program{
    static void Main(string[] args)
    {
    account acc=new account();
    currentaccount ca= new currentaccount();
    acc.signer(ca);}
}