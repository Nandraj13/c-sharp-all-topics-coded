﻿/*class Genericclass<T>
{
    T data;
    public Genericclass(T data)
    {
        this.data=data;
    }
    public void display()
    {
        Console.WriteLine(data);
    }
}
class program{
    static void Main(string[] args)
    {
        Genericclass<string> s=new Genericclass<string>("hello");
        Genericclass<int> i=new Genericclass<int>(23);
        s.display();
        i.display();
    }
}*/

//generic class example using properties

/*class Genericclass<T>{
    T data;
    public T Data{
        set{
            this.data=value;
        }
        get{
            return this.data;
        }
    }
}*/

//generic methods 
/*class genericmethods{
   
    public void adder<T>(T x,T y)
    {
        dynamic a=x;
        dynamic b=y;
        Console.WriteLine(a);
    }
}
class program{
     static void Main(string[] args){
        genericmethods g1=new genericmethods();
        g1.adder(1,2);
    }
}*/

/*class generic<T> where T:class{
    dynamic box;
    public generic(T x)
    {
        box=x;
    }
    public void display<U>(U x)
    {
        Console.WriteLine(x);
        for (int i = 0; i < box.Length; i++)
        {
            Console.WriteLine(box[i]);
        }
    }

}
class program{
    static void Main(string[] args){
        generic<int[]> g=new generic<int[]>(new int[]{1,2,3,4,5});
        g.display<string>("hello programmer");

    }
}*/

//generic interface

public interface bultaro<T>{
   void add(T x,T y);
   void sub(T x, T y);
}
class program : bultaro<int>
{
    public void add(int x, int y)
    {
        Console.WriteLine(x+y);
    }

    public void sub(int x, int y)
    {
        Console.WriteLine(x-y);
    }
    static void Main(string[] args)
    {
        program p=new program();
        p.add(10,5);
        p.sub(10,5);
    }
}