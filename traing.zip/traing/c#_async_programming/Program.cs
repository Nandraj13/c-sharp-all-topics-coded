﻿
/*class asyncdemo{
    static void Main(string[] args)
    {
        var Asyncres=Asyncmethod(5);
        var syncres=Syncmethod(5);
        Console.WriteLine("sync method result: {0}",syncres);
        Console.WriteLine("sync method result: {0}",Asyncres.Result);

    }
    public static int Syncmethod(int x)
    {
        int result=0;
        for (int i = 0; i < x; i++)
        {
            Thread.Sleep(200);
            Console.WriteLine($"async method {i}");
            result=result+i;
        }
        return result;
    }
    public static Task<int> Asyncmethod(int x)
    {
       
        Task<int> task=new Task<int>(()=>{
             int result=0;
        for (int i = 0; i < x; i++)
        {
            Thread.Sleep(200);
            Console.WriteLine($"sync method {i}");
            result=result+i;
        }
        return result;
        });
        task.Start();
        return task;
    }
}

//example 2
class Employee{
    static async Task Main(string[] args){
        var ans= await longmethod();
        shortmethod();
        Console.WriteLine(ans);
       
      
    }
    public static void shortmethod(){
        Console.WriteLine("this is a short method");
    }
    public static Task<int> longmethod()
    {
        Task<int> task=new Task<int>(()=>{
            int res=0;
            for (int i = 0; i <= 10; i++)
            {
                Thread.Sleep(1000);
                res=res+i;
            }
            return res;
        });
        task.Start();
        return task;
       
    }
}

//example 3

class Employee{
    public async Task<string> getempdata()
    {
        HttpClient hp=new HttpClient();
        Uri url=new Uri("https://jsonplaceholder.typicode.com/todos");
        var task=await hp.GetAsync(url);

        if(task.IsSuccessStatusCode)
        {
            return await task.Content.ReadAsStringAsync();
        }
        else
        {
            return null;
        }
    }
}
class program{
      static async Task Main(string[] args)
        {
        Console.WriteLine(" welcome to the employee class");
        Employee emp=new Employee();
        var data= await emp.getempdata();
        Console.WriteLine(data);
        }
}



// example 4

class demoasync{
    static async Task Main(string[] ags)
    {
         await method1();
         await method2();
    }
    public static async Task method1()
    {
        Console.WriteLine("hello this is a async method1");
        await Task.Delay(1000);
        Console.WriteLine("this is end of async method1");
    }
    public static async Task method2()
    {
        Console.WriteLine("hello this is a async method2");
        await Task.Delay(1000);
        Console.WriteLine("this is end of async method2");
    }
}


//example 5
class paralleltask{
    public static void shortmethod(){
        Console.WriteLine("this is short method");
        for(int i=0;i<5;i++)
        {
           Thread.Sleep(200);
            Console.WriteLine("sync method {0}",i);
        }
    }
    public static Task<int> longmethod()
    {
        Task<int> t=new Task<int>(()=>{
             for(int i=0;i<5;i++)
        {
            Thread.Sleep(200);
            Console.WriteLine("async method {0}",i);
        }
            return 10;
        });
        t.Start();
        return t;
    }
    static async Task Main(){
        var x= await longmethod();
        shortmethod();
        Console.WriteLine(x);
    }
}

//example 6
class calc{
    public static Task<int> add(int x,int y)
    {
        Task<int> t1=new Task<int>(()=>{
            Console.WriteLine("adding.....");
            Thread.Sleep(1000);
            Console.WriteLine("operation overrr");
            return x+y;
        });
        t1.Start();
        return t1;
    }
     public static Task<int> sub(int x,int y)
    {
        Task<int> t1=new Task<int>(()=>{
            Console.WriteLine("subtracting.....");
            Thread.Sleep(1000);
            Console.WriteLine("operation overrr");
            return x-y;
        });
        t1.Start();
        return t1;
    }
    static async Task Main(string[] args)
    {
        var x=await add(20,10);
        var y=await sub(20,10);
        Console.WriteLine(x);
        Console.WriteLine(y);

    }
}

//example 7
class calc{
    public static Task<int> add(int x,int y)
    {
        Task<int> t1=new Task<int>(()=>{
            Console.WriteLine("adding.....");
            Thread.Sleep(1000);
            Console.WriteLine("operation overrr add");
            return x+y;
        });
        t1.Start();
        return t1;
    }
     public static Task<int> sub(int x,int y)
    {
        Task<int> t1=new Task<int>(()=>{
            Console.WriteLine("subtracting.....");
            Thread.Sleep(1000);
            Console.WriteLine("operation overrr subtract");
            return x-y;
        });
        t1.Start();
        return t1;
    }
    public static  void syncmethod()
    {
       Console.WriteLine("quick method"); 
    }
    static void Main(string[] args)
    {
        var x= add(20,10);
        syncmethod();
        var y= sub(20,10);
        Console.WriteLine(x.Result);
        Console.WriteLine(y.Result);

    }
}*/

//example 8

class lastexmple{
    public static void shortmethod()
    {
        for(int i=0;i<10;i++)
        {
            Thread.Sleep(200);
            Console.WriteLine("short method {0}",i);
        }
    }
    public static Task<string> longmethod()
    {
        Task<string> t=new Task<string>(()=>{
            for(int i=0;i<10;i++)
            {
                Thread.Sleep(200);
                Console.WriteLine("long maehtod {0}",i);
            }
            return "from long method";
        });
        t.Start();
        return t;

    }
    static async Task Main(string[] args)
    {
        var x= await longmethod();
        shortmethod();
        Console.WriteLine(x);
    }
}