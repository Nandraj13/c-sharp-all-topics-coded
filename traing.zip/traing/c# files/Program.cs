﻿using System.IO;
string name="hello how are you.....";
File.AppendAllText("dummy.txt",name);
string[] getname=File.ReadAllLines("dummy.txt");
Console.WriteLine(getname[0]);
File.Copy("dummy.txt","dummy2.txt");
File.Delete("dummy.txt");
