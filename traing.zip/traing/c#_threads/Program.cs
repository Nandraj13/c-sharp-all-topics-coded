﻿class multithread{
    public static void method1()
    {
        for(int i=0;i<10;i++)
        {
            Thread.Sleep(200);
            Console.WriteLine("hello from method1 {0}",i);
        }
    }
    public static void method2()
    {
        for(int i=0;i<10;i++)
        {
            Thread.Sleep(200);
            Console.WriteLine("hello from method2 {0}",i);
        }
    }
    static void Main(string[] args)
    {
        Thread t1=new Thread(method1);
        Thread t2=new Thread(method2);
        t1.Start();
        t1.Join();
        t2.Start();
    }

}