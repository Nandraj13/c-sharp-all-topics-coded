﻿/*class Linqquery{
    static void Main(string[] args){
        string[] names={"nandraj","nishant","chirag","raj","ravi","rohan","mihir","shyamal","gopal","govind"};
        dynamic q=from name in names where name.StartsWith("n") select name;
        foreach (var item in q)
        {
            Console.WriteLine("your name is {0}",item);
        }
         q=from name in names where name.EndsWith("l") select name;
        foreach (var item in q)
        {
            Console.WriteLine("your name is {0}",item);
        }
         q=from name in names where name.Length>5 select name;
         foreach (var item in q)
        {
            Console.WriteLine("your name is {0}",item);
        }
         q=from name in names where name.Length>5 
    }
}

class Students{
    string name;
    int age;
    static void Main(string[] args)
    {
        Students[] s={
            new Students(){name="nandraj",age=20},
            new Students(){name="chirag",age=30},
            new Students(){name="gopal",age=40}
        };
        display(s);
    }
    public static void display(Students[] s){
      var x=s.Where(y=>y.name.Length>5).ToArray();
      foreach (var item in x)
      {
        Console.WriteLine(item.age);
        Console.WriteLine(item.name);
      }
      
    } 
}*/

//example2
/*int[] x=new int[5]{20,10,30,40,50};
dynamic collection=x.Where(y=>y>10).ToArray();
foreach (var item in collection)
{
    Console.WriteLine(item);
}
collection=x.Where(y=>(y/2)>10).ToArray();
foreach (var item in collection)
{
    Console.WriteLine(item);
}*/

//typeof method
/*using System.Collections;
var arr= new ArrayList();
arr.AddRange(new int[5]{1,2,3,4,5});
arr.AddRange(new string[5]{"nandraj","govind","gopal","raj","ravi"});
foreach (var item in arr)
{
    Console.WriteLine(item);
}
var f=from s in arr.OfType<string>() select s;
foreach (var item in f)
{
    Console.WriteLine(item);
}

var d=from s in arr.OfType<int>() select s;
foreach (var item in d)
{
    Console.WriteLine(item);
}*/

//orderby
 /*string[] names={"nandraj","nishant","chirag","raj","ravi","rohan","mihir","shyamal","gopal","govind"};
 dynamic q=from s in names orderby s descending select s;
 Console.WriteLine("descending order---------");
 foreach(var x in q)
 {
    Console.WriteLine(x);
 }
Console.WriteLine("ascending order---------");
 q= from s in names orderby s select s;
 foreach(var x in q)
 {
    Console.WriteLine(x);
 }
 //orderby methods
 q=names.OrderBy(s=>s);
 foreach(var x in q)
 {
    Console.WriteLine(x);
 }
 q=names.OrderByDescending(s=>s);
 foreach(var x in q)
 {
    Console.WriteLine(x);
 }*/
//group by

/*class student{
    public string name;
    public int id;
    public int age;
    public int statndardID;
    public List<student> slist;
    static void Main(string[] args)
    {
            student stu=new student();
            stu.slist=new List<student>(){
            new student(){id=1,name="nandraj",age=22, statndardID=1 },
            new student(){id=2,name="karan",age=20, statndardID=1},
            new student(){id=3,name="mihir",age=20,statndardID=2},
            new student(){id=4,name="dhaval",age=22,statndardID=2},
            new student(){id=5,name="chirag",age=21,statndardID=3},
            new student(){id=6,name="hridan",age=21,statndardID=3}
        };
        var x=from s in stu.slist group s by s.age;
        //or
        // var x = stu.slist.GroupBy(s=>s.age);
        foreach (var item in x)
        {
            Console.WriteLine(item.Key);
            foreach (var item1 in item)
            {
                Console.WriteLine(item1.name);
            }
        }
    }
}*/

//joins
/*
public class Student{
    public int StudentID{get;set;}
    public int StandardID{get;set;}
    public string StudentName{get;set;}

}
public class Standard{
    public int StandardID{get;set;}
    public string StandardName{get;set;}

}
public class joins{
    static void Main(string[] args)
    {
         IList<Student> studentList = new List<Student>() { 
    new Student() { StudentID = 1, StudentName = "John", StandardID =1 },
    new Student() { StudentID = 2, StudentName = "Moin", StandardID =1 },
    new Student() { StudentID = 3, StudentName = "Bill", StandardID =2 },
    new Student() { StudentID = 4, StudentName = "Ram",  StandardID =2 },
    new Student() { StudentID = 5, StudentName = "Ron" } 

    };
    IList<Standard> standardList=new List<Standard>(){
        new Standard() { StandardID=1, StandardName="std 1"},
        new Standard() { StandardID=2, StandardName="std 2"},
        new Standard() { StandardID=3, StandardName="std 3"},
    };
   // dynamic  x=from s in studentList join st in standardList on s.StandardID equals st.StandardID select new {sname=s.StudentName, stdname=st.StandardName};
    dynamic x= from s in studentList select new{ name="Mr."+s.StudentName};
    foreach (var item in x)
    {
        Console.WriteLine(item.name);
        
    }
    var y=studentList.Any(s=>s.StandardID>0);
    Console.WriteLine(y);

    }
  
   
}*/

//aggregate

class Agggregate{
    static void Main(string[] args)
    {
        string[] s={"Bhavnagar","Botad","Anand","Rajkot","Daman"};
        dynamic x=s.Aggregate((a,b)=>a+","+b);
        Console.WriteLine(x);
        int[] i={1,2,3,4,5};
        x=i.Aggregate((a,b)=>a+b);
        Console.WriteLine(x);
        x=s.Aggregate((a,b)=>a.ToUpper()+","+b.ToUpper());
        Console.WriteLine(x);
        x=s.Aggregate((a,b)=>a.ToUpper());
        Console.WriteLine(x);
        
        //average func

        x=i.Average();
        Console.WriteLine("average of the array: {0}",x);

        //count func

        x=i.Count();
        Console.WriteLine("total {0} elements",x);
        x=i.Count(i=>i>2);
        Console.WriteLine("total {0} elements are greater than 2",x);

        x=s.Max(s=>s.Length);
        Console.WriteLine(x); 

        // max func

        x=i.Max(i => {
            if(i%2==0)
            {
                return i;
            }
            return 0;
        });
        Console.WriteLine(x);

        // sum func 
        x=i.Sum(i=>{
            if(i>2){
                return i;
            }
            return 0;
        });
        Console.WriteLine(x);

        // first and last

        x=i.First();
         Console.WriteLine("first element in array {0}",x);
        x=i.Last();
         Console.WriteLine("Last element in array {0}",x);
        x=i.SingleOrDefault(i=>i>4);

        //range repeat

        x=Enumerable.Range(10,10);
        foreach(int q in x){
            Console.WriteLine(q);
        }

        x=Enumerable.Repeat(10,10);
         foreach(int q in x){
            Console.WriteLine(q);
        }
        // distinct expect union intersection
        var newlist=new List<int>(){1,1,1,2,3,4,4,5,6};
        x=newlist.Distinct();
        foreach(int q in x){
            Console.WriteLine(q);
        }
        Console.WriteLine("skip skipwhile take takewhile demo------");
        //skip skipwhile take takewhile

       IList<string> strList = new List<string>(){ "One", "Two", "Three", "Four", "Five" };
        x=strList.Skip(2);
        foreach(string q in x){
            Console.WriteLine(q);
        }
        x=strList.SkipWhile(i=>i.Length<4);
         foreach(string q in x){
            Console.WriteLine(q);
        }
        x=strList.Take(2);
        foreach(string q in x){
            Console.WriteLine(q);
        }
        x=strList.TakeWhile(i=>i.Length<4);
         foreach(string q in x){
            Console.WriteLine(q);
        }

    }
}