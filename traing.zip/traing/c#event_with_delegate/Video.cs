public class Video{
    public string Title{get;set;}
}