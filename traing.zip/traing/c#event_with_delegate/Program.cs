﻿public class program{
    
    static void Main(string[] args)
    {
        var video=new Video(){Title="Video 1"};
        var videoencoder=new VideoEncoder();//publisher
        var ms=new Mailservice();//subscriber
        videoencoder.VideoEncoded+=ms.SendMail;//subscription
        videoencoder.Encode(video);
    }
}
public class Mailservice{
    public void SendMail(object source, EventArgs args)
    {
        Console.WriteLine("Sending mail....");
        Console.WriteLine("Mail sent......");
    }

}