﻿/*class delegates{
    public static int add(int x,int y,int z){
        return x+y+z;
    }
    public static void sub(int x, int y, int z)
    {
        Console.WriteLine(x-y-z);
    }
    public static bool checknum(int x)
    {
        if(x>10)
            return true;
        return false;
    }
    static void Main(string[] args)
    {
        Func<int,int,int,int> adder=add;
        Action<int,int,int> subtrator=sub;
        Predicate<int> checker=checknum;

        int ans=adder(10,20,30);
        subtrator(30,10,5);
        bool status=checker(20);

        Console.WriteLine(ans);
        Console.WriteLine(status);


    }
}*/

//simple delegates

class simpledelegates{
    public delegate void adder (int x,int b);
    static void Main(string[] args){
        simpledelegates s=new simpledelegates();
        adder x=add;
        x(20,20);
    }
    public static void add(int a,int b)
    {
        Console.WriteLine(a+b);
    }
}